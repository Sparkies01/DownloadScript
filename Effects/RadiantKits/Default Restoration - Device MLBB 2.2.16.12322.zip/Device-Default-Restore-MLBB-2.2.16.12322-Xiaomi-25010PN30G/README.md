# Device default restoration backup

This package restores the exact Mobile Legends resource state captured before the
Radiant kit was installed on the Xiaomi 25010PN30G device.

## Compatibility boundary

- Package: `com.mobile.legends`
- MLBB version: `2.2.16.12322` (`211812322`)
- Android: 16 / API 36
- Captured texture route: ASTC plus standard fallback atlases

Do not treat this as a universal or future-version backup. MLBB updates can replace
these bundles. Verify the installed game version before restoring.

## Complete restoration behavior

1. Stop Mobile Legends.
2. Delete only the nine relative paths listed in `deleteFiles` in
   `restore-manifest.json`.
3. Copy the six files under `payload/` to the matching paths beneath
   `files/dragon2017/assets/`.
4. Flush pending writes and verify every restored file against its declared size and
   SHA-256.

The explicit deletion step is required. Nine Radiant effect files did not exist in
the pre-install baseline, so overwriting files from an ordinary ZIP cannot perform a
complete default restoration by itself.

The relative payload and deletion paths can be applied through Direct Access,
Shizuku, or Folder Access/SAF as long as that method has valid read/write permission
to the same MLBB assets root.

The public `Radiant.Kits.Backup.zip` is retained separately for provenance, but three
of its four atlas files differ from this device's captured MLBB baseline.
